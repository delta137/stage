function [ res ] = argu(pref,h,x)
res=pref*(-x+h)
end

